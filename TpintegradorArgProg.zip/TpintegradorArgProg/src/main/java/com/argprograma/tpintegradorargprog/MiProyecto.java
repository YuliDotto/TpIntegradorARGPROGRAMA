package com.argprograma.tpintegradorargprog;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MiProyecto {

    public static void main(String[] args) throws IOException {

        String file1 = ("C:\\Users\\Martin\\Desktop\\curso arg programa\\TPIntegrador\\Resultados.csv");
        String file2 = ("C:\\Users\\Martin\\Desktop\\curso arg programa\\TPIntegrador\\Pronosticos.csv");
        List<Persona> personas;
        personas = new ArrayList<Persona>();
        System.out.println("pronostico: ");

        //porcion del codigo que crea las rondas segun el numero en detalle [0]
        HashMap<Integer, Ronda> map = new HashMap<Integer, Ronda>();

        for (String linea : Files.readAllLines(Paths.get(file1))) {
            String[] detalle = linea.split(";");

            int numeroRonda = Integer.parseInt(detalle[0]);
            Ronda r1 = map.get(numeroRonda);

            if (r1 == null) {
                r1 = new Ronda(numeroRonda);
                map.put(numeroRonda, r1);
            }
        }

        for (String linea : Files.readAllLines(Paths.get(file1))) {
            String[] detalle = linea.split(";");

            //se verifica que los goles sean un numero entero
            if (detalle[2].matches("[0-9]*") && detalle[3].matches("[0-9]*")) {

                String equ1 = detalle[1];
                String equ2 = detalle[4];

                int goleseq1 = Integer.parseInt(detalle[2]);
                int goleseq2 = Integer.parseInt(detalle[3]);

                Partido partido = new Partido(equ1, equ2, goleseq1, goleseq2);

                partido.setIdPartido(Integer.parseInt(detalle[0]));

                //se crea un arraylist de partidos por cada instancia de ronda y se agregan los partidos correspondientes
                for (int r = 1; r <= map.size(); r++) {
                    List<Partido> partidos;
                    partidos = new ArrayList<Partido>();
                    if (map.get(r).getNumero() == partido.getIdPartido()) {
                        partidos.add(partido);
                        map.get(r).agregarPartido(partido);
                    }

                }

            } else {
                System.out.println("los goles no son numeros enteros");
            }
        }

        //creamos las personas y las referenciamos en un , mapa
        HashMap<Integer, Persona> persMap = new HashMap<Integer, Persona>();
        for (String linea : Files.readAllLines(Paths.get(file2))) {
            String[] detalle = linea.split(";");

            int key = (Integer.parseInt(detalle[6]));
            Persona p1 = persMap.get(key);

            if (p1 == null) {
                p1 = new Persona(key, detalle[0]);
                persMap.put(key, p1);
            }
        }

        // AGREGAMOS NUEVAS PERSONAS A NUESTRO MAPA DE PERSONAS REFERENCIADO POR EL ARRAY (PARA QUE CREE DISTINTOS OBJETOS PERSONA)
        for (int d = 1; d <= map.size(); d++) {
            for (int t = 1; t <= persMap.size(); t++) {
                Persona pRef = new Persona();
                pRef.setNombre(persMap.get(t).getNombre());
                map.get(d).agregarPersona(pRef);
            }
        }

        for (String linea : Files.readAllLines(Paths.get(file2))) {

            String[] detalle = linea.split(";");
            Pronostico pr1 = new Pronostico();

            for (String linea2 : Files.readAllLines(Paths.get(file1))) {
                String[] detalle2 = linea2.split(";");
                //se verifica que los goles sean un numero entero
                if (detalle2[2].matches("[0-9]*") && detalle2[3].matches("[0-9]*")) {

                    String equ1 = detalle2[1];
                    String equ2 = detalle2[4];

                    int goleseq1 = Integer.parseInt(detalle2[2]);
                    int goleseq2 = Integer.parseInt(detalle2[3]);

                    Partido partido = new Partido(equ1, equ2, goleseq1, goleseq2);

                    partido.setIdPartido(Integer.parseInt(detalle2[0]));

                    if (detalle[1].equalsIgnoreCase(partido.getEquipo1().getNombre())
                            && detalle[5].equalsIgnoreCase(partido.getEquipo2().getNombre())) {
                        pr1.setPartido(partido);
                        if (detalle[2].equalsIgnoreCase("x")) {

                            pr1.setEquipo(partido.getEquipo1());

                            pr1.setResultado(ResultadoEnum.GANADOR);
                        } else if (detalle[3].equalsIgnoreCase("x")) {

                            pr1.setResultado(ResultadoEnum.EMPATE);

                        } else if (detalle[4].equalsIgnoreCase("x")) {

                            pr1.setEquipo(partido.getEquipo2());
                            pr1.setResultado(ResultadoEnum.GANADOR);
                        }
                    } else {

                    }

                }
            }
            //añadimos el puntaje del pronostico a los objetos persona
            for (int r = 1; r <= map.size(); r++) {
                for (int b = 0; b < map.get(r).getPersonas().size(); b++) {
                    for (int i = 0; i < map.get(r).getPartidos().size(); i++) {
                        if (map.get(r).getPartidos().get(i).getEquipo1().getNombre().equalsIgnoreCase(pr1.getPartido().getEquipo1().getNombre())
                                && map.get(r).getPartidos().get(i).getEquipo2().getNombre().equalsIgnoreCase(pr1.getPartido().getEquipo2().getNombre())
                                && map.get(r).getNumero() == pr1.getPartido().getIdPartido()
                                && map.get(r).getPersonas().get(b).getNombre().equalsIgnoreCase(detalle[0])) {
                            map.get(r).getPersonas().get(b).agregarPronostico(pr1);
                            map.get(r).getPersonas().get(b).setPronostico(pr1);
                            map.get(r).getPersonas().get(b).setPuntajePersona(pr1.calcularPronostico() + map.get(r).getPersonas().get(b).getPuntajePersona());
                            map.get(r).getPersonas().get(b).setPronosticosAcertados(pr1.pronosticoAcertado() + map.get(r).getPersonas().get(b).getPronosticosAcertados());
                        }
                    }
                }
            }
        }
        for (int r = 1; r <= map.size(); r++) {
            for (int b = 0; b < map.get(r).getPersonas().size(); b++) {
                System.out.println("el puntaje de la ronda " + map.get(r).getNumero() + " de la persona " + map.get(r).getPersonas().get(b).getNombre() + 
                                    " es de " + map.get(r).getPersonas().get(b).getPuntajePersona() + 
                                     ", cantidad de pronosticos acertados = " +  map.get(r).getPersonas().get(b).getPronosticosAcertados());
            }
        }
    }
}
