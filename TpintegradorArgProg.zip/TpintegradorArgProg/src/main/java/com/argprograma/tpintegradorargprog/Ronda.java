package com.argprograma.tpintegradorargprog;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Ronda {

    private int numero;
    private List<Partido> partidos;
    //HashMap <Integer, Partido> map = new HashMap <Integer, Partido> ();
    private List<Persona> personas;
    
    public Ronda(){
        
    }
    
    public Ronda(int num){
        this.numero = num;
        this.partidos = new ArrayList<Partido>();
        this.personas = new ArrayList<Persona>();
    }
    
    
    public Ronda(String Resultados) throws IOException {
        
        int indice = 0;
        this.partidos = new ArrayList<Partido>();
        
        for (String linea : Files.readAllLines(Paths.get(Resultados))) {
            
            
            String[] detalle = linea.split(";");
            this.numero = Integer.parseInt(detalle[0]);
            
            if (detalle[2].matches("[0-9]*") && detalle[3].matches("[0-9]*")) {

                String equ1 = detalle[1];
                String equ2 = detalle[4];

                int goleseq1 = Integer.parseInt(detalle[2]);
                int goleseq2 = Integer.parseInt(detalle[3]);

                Partido partido = new Partido(equ1, equ2, goleseq1, goleseq2);

                indice = indice + 1;
                partido.setIdPartido(Integer.parseInt(detalle[0]));

                    this.partidos.add(partido);
                    
                    
                    
                   //  map.put(partido.getIdPartido(), partido);
                    
                    if (partido.getIdPartido() == Ronda.this.getNumero()) {
                }
            } else {
                System.out.println("los goles no son numeros enteros");
            }
        }
    }

    public void agregarPartido(Partido p1) {
        this.partidos.add(p1);
    }
    
      public void agregarPersona(Persona p1) {
        this.personas.add(p1);
    }
      
        public void quitarPersona(Persona p1) {
        this.personas.remove(p1);
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<Partido> getPartidos() {
        return partidos;
    }

    public void setPartidos(List<Partido> partidos) {
        this.partidos = partidos;
    }

    public List<Persona> getPersonas() {
        return personas;
    }

    
    
}
