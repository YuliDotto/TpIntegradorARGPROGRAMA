package com.argprograma.tpintegradorargprog;

import java.util.List;

public class Partido {
    
    private int idPartido;
    private Equipo equipo1;
    private Equipo equipo2;
    private int golesEquipo1;
    private int golesEquipo2;
    
    
    
    public Partido(){
        
    }
    
    public Partido(int num){
        this.idPartido = num;
    }
    
    public Partido(String eq1, String eq2, int goles1, int goles2){
        this.equipo1 = new Equipo(eq1);
        this.equipo2 = new Equipo(eq2);
        this.golesEquipo1 = goles1;
        this.golesEquipo2 = goles2;
    }


    public Equipo getEquipo1() {
        return equipo1;
    }

    public void setEquipo1(Equipo equipo1) {
        this.equipo1 = equipo1;
    }

    public Equipo getEquipo2() {
        return equipo2;
    }

    public void setEquipo2(Equipo equipo2) {
        this.equipo2 = equipo2;
    }

    public int getGolesEquipo1() {
        return golesEquipo1;
    }

    public void setGolesEquipo1(int golesEquipo1) {
        this.golesEquipo1 = golesEquipo1;
    }

    public int getGolesEquipo2() {
        return golesEquipo2;
    }

    public void setGolesEquipo2(int golesEquipo2) {
        this.golesEquipo2 = golesEquipo2;
    }

    public int getIdPartido() {
        return idPartido;
    }

    public void setIdPartido(int idPartido) {
        this.idPartido = idPartido;
    }

    
    @Override
    public String toString() {
        return "Partido{" + "equipo1=" + equipo1 + ", equipo2=" + equipo2 + ", golesEquipo1=" + golesEquipo1 + ", golesEquipo2=" + golesEquipo2 +  '}';
    }
    
    
   public ResultadoEnum calcularResultado(Equipo eq) {
       
       //esta porcion del metodo nos ubica en equipo1 el equipo que estemos calculando el resultado
       if(eq == this.equipo2){
           Equipo aux = equipo1;
           equipo1 = equipo2;
           equipo2 = aux;
           int aux2 = golesEquipo1;
           golesEquipo1 = golesEquipo2;
           golesEquipo2 = aux2;
       }
       

       //calcula el resultado
       if(this.golesEquipo1>this.golesEquipo2){
           return ResultadoEnum.GANADOR;
       }
       else if(this.golesEquipo1<this.golesEquipo2){
           return ResultadoEnum.PERDEDOR;
       }
       else
           return ResultadoEnum.EMPATE;
    }
    
    
    
    
    
    
}
