package com.argprograma.tpintegradorargprog;

import java.util.ArrayList;
import java.util.List;

public class Persona {
    
    private String nombre;
    private Pronostico pronostico;
    private int puntajePersona;
    private List<Pronostico> pronosticos;
    private int pronosticosAcertados;

      public Persona(int num,String nombre){
       this.pronosticos = new ArrayList<Pronostico>();
       this.nombre = nombre;
    }
    
    public Persona(){
       this.pronosticos = new ArrayList<Pronostico>();
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Pronostico getPronostico() {
        return pronostico;
    }

    public void setPronostico(Pronostico pronostico) {
        this.pronostico = pronostico;
    }

    public int getPuntajePersona() {
        return puntajePersona;
    }


    public void setPuntajePersona(int puntajePersona) {
        this.puntajePersona = puntajePersona;
    }

    public List<Pronostico> getPronosticos() {
        return pronosticos;
    }

    public void setPronosticos(List<Pronostico> pronosticos) {
        this.pronosticos = pronosticos;
    }

   public void agregarPronostico(Pronostico pr1) {
       this.pronosticos.add(pr1);
    }

    public int getPronosticosAcertados() {
        return pronosticosAcertados;
    }

    public void setPronosticosAcertados(int pronosticosAcertados) {
        this.pronosticosAcertados = pronosticosAcertados;
    }
    
   
    
}


